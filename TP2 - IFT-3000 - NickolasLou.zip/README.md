Version .NET : 4.8

OS : Windows 11

IDE : Visual Studio 2022

Commentaires (facultatif) : Equipe de 1
Note : Dans les étapes pour la vidéo “Perdre un point de vie sur le bateau espion en étant positionnée sous l’avion.”, je ne vois pas où il faut coder cette fonction dans le document PDF.
